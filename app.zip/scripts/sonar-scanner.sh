#!/bin/bash

# SonarQube server URL
SONAR_HOST_URL="http://localhost:9000"
# SonarQube token
SONAR_TOKEN="sqp_9c79ccb0788a9bd6e13a56f08abb5ed2f336a442"
# Project key
SONAR_PROJECT_KEY="foodie"
# Source directory
SONAR_SOURCES="."

# Run SonarScanner
../sonar-scanner-6.0.0.4432-macosx/bin/sonar-scanner \
  -Dsonar.projectKey=${SONAR_PROJECT_KEY} \
  -Dsonar.sources=${SONAR_SOURCES} \
  -Dsonar.host.url=${SONAR_HOST_URL} \
  -Dsonar.login=${SONAR_TOKEN} -X
